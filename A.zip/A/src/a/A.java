package a;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class A {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int sayi;
        do{
           sayi=SayiGirisi();
        } while (sayi<0);
        YaziylaYaz(sayi);
            int birler = (sayi % 10);
            sayi = (sayi / 10);
            int onlar = (sayi % 10);
            sayi = (sayi / 10);
            int yuzler = (sayi % 10);
            sayi = (sayi / 10);
            int binler = (sayi % 10);
             sayi = (sayi / 10);
            int onbinler = (sayi % 10);
            sayi = (sayi / 10);
            int yuzbinler = (sayi % 10);
            sayi = (sayi / 10);
            int milyonlar = (sayi % 10);
            System.out.println(("milyonlar Basamağı: " + milyonlar));
            System.out.println(("yüzbinler Basamağı: " + yuzbinler));
            System.out.println(("onbinler Basamağı: " + onbinler));
            System.out.println(("Binler Basamağı: " + binler));
            System.out.println(("Yüzler Basamağı: " + yuzler));
            System.out.println(("Onlar Basamağı: " + onlar));
            System.out.println(("Birler Basamağı: " + birler));
    }
    
    static int SayiGirisi(){
        Scanner input=new Scanner (System.in);
        System.out.println("bir sayi giriniz: ");
        int a=0;
        try{
             a=input.nextInt();
        } catch (Exception e) {
            a=-1;
            System.out.println("\nhata: "+ e.getMessage());
        
        }
        return a;
    }
    static void YaziylaYaz(int sayi)
    {
        if (sayi <10)
            BirlikYaz(sayi);
        else if (sayi <100){
            OnlukYaz(sayi/10);
            BirlikYaz(sayi%10);
        }
         else if (sayi <1000){
            YuzlukYaz(sayi/100);
            OnlukYaz(sayi%10);
            BirlikYaz(sayi%10);
        }
           else if (sayi <10000){
             BinlikYaz (sayi/1000); 
            YuzlukYaz(sayi/100);
            OnlukYaz(sayi/100);
            BirlikYaz(sayi%10);
        }
          else if (sayi <100000){
              OnBinlikYaz(sayi/10000);
             BinlikYaz (sayi/1000); 
            YuzlukYaz(sayi/100);
            OnlukYaz(sayi/10);
            BirlikYaz(sayi%10);
        }
          else if (sayi <1000000){
             YuzbinlikYaz(sayi/100000);
            OnBinlikYaz(sayi/10000); 
            BinlikYaz (sayi/1000); 
            YuzlukYaz(sayi/100);
            OnlukYaz(sayi/10);
            BirlikYaz(sayi%10);
        }
          else if (sayi <10000000){
            MilyonlukYaz(sayi/1000000);
            YuzbinlikYaz(sayi/100000);
            OnBinlikYaz(sayi/10000);
            BinlikYaz (sayi/1000); 
            YuzlukYaz(sayi/100);
            OnlukYaz(sayi/10);
            BirlikYaz(sayi%10);
        }    
               
        else
         System.out.println("En fazla 6 basamaklı sayı giriniz... ");
        
        
        
    }
    static void BirlikYaz(int b){
        if(b==0)
            System.out.println("Sıfır");
        else if(b==1) System.out.println("Bir");
        else if(b==2) System.out.println("İki");
        else if(b==3) System.out.println("Üç");
        else if(b==4) System.out.println("Dört");
        else if(b==5) System.out.println("Beş");
        else if(b==6) System.out.println("Altı");
        else if(b==7) System.out.println("Yedi");
        else if(b==8) System.out.println("Sekiz");
        else if(b==9) System.out.println("Dokuz");
        else System.out.println("--");
    }
    
    static void OnlukYaz(int b){
        switch (b){
            
            case 1: System.out.println("On");break;
            case 2: System.out.println("Yirmi");break;
            case 3: System.out.println("Otuz");break;
            case 4: System.out.println("Kırk");break;
            case 5: System.out.println("Elli");break;
            case 6: System.out.println("Altmş");break;
            case 7: System.out.println("Yetmiş");break;
            case 8: System.out.println("Seksen");break;
            case 9: System.out.println("Doksan");break;
            
            
            default :
                break;
        }

        }

       
static void YuzlukYaz(int c){
        switch (c){
            
            case 1: System.out.println("Yüz");break;
            case 2: System.out.println("İkiyüz");break;
            case 3: System.out.println("Üçyüz");break;
            case 4: System.out.println("Dörtyüz");break;
            case 5: System.out.println("Beşyüz");break;
            case 6: System.out.println("Altıyüz");break;
            case 7: System.out.println("Yediyüz");break;
            case 8: System.out.println("Sekizyüz");break;
            case 9: System.out.println("Dokuzyüz");break;
            
            
            default :
                break;
        }

        }

static void MilyonlukYaz(int d){
        switch (d){
            
            case 1: System.out.println("Bir Milyon");break;
            case 2: System.out.println("İki Milyon");break;
            case 3: System.out.println("Üç Milyon");break;
            case 4: System.out.println("Dört Milyon");break;
            case 5: System.out.println("Beş Milyon");break;
            case 6: System.out.println("Altı Milyon");break;
            case 7: System.out.println("Yedi Milyon");break;
            case 8: System.out.println("Sekiz Milyon");break;
            case 9: System.out.println("Dokuz Milyon");break;
            
            
            default :
                break;
        }

        }

static void YuzbinlikYaz(int e){
        switch (e){
            
            case 1: System.out.println("yüzbin");break;
            case 2: System.out.println("İkiyüzbin");break;
            case 3: System.out.println("üçyüzbin");break;
            case 4: System.out.println("dörtyüzbin");break;
            case 5: System.out.println("beşyüzbin");break;
            case 6: System.out.println("altıyüzbin");break;
            case 7: System.out.println("Yediyüzbin");break;
            case 8: System.out.println("Sekizyüzbin");break;
            case 9: System.out.println("Dokuzyüzbin");break;
            
            
            default :
                break;
        }

        }

static void BinlikYaz(int f){
        switch (f){
            
            case 1: System.out.println("Bin");break;
            case 2: System.out.println("İkibin");break;
            case 3: System.out.println("Üçbin");break;
            case 4: System.out.println("Dörtbin");break;
            case 5: System.out.println("Beşbin");break;
            case 6: System.out.println("Altıbin");break;
            case 7: System.out.println("Yedibin");break;
            case 8: System.out.println("Sekizbin");break;
            case 9: System.out.println("Dokuzbin");break;
            
            
            default :
                break;
        }

        }

static void OnBinlikYaz(int g){
        switch (g){
                       

            case 1: System.out.println("Onbin");break;
            case 2: System.out.println("Yirmibin");break;
            case 3: System.out.println("Otuzbin");break;
            case 4: System.out.println("Kırkbin");break;
            case 5: System.out.println("Ellibin");break;
            case 6: System.out.println("Altmışbin");break;
            case 7: System.out.println("Yetmişbin");break;
            case 8: System.out.println("Seksenbin");break;
            case 9: System.out.println("Doksanbin");break;
            
            
            default :
                break;
        }

        }


        }
